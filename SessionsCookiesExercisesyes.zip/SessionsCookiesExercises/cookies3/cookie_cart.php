<?php
session_start();

// 1. LOGIN STEP
if (!isset($_SESSION['username'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
        $_SESSION['username'] = trim($_POST['username']);
        header("Location: cookie_cart.php");
        exit();
    }
    echo '<form method="post">
        <h2>Login</h2><input name="username" required><input type="submit" value="Login">
    </form>';
    exit();
}

$username = $_SESSION['username'];
$cookieName = "cart_" . $username;

// 2. LOAD FROM COOKIE
if (!isset($_SESSION['cart'])) {
    if (isset($_COOKIE[$cookieName]) && $_COOKIE[$cookieName] !== "") {
        $_SESSION['cart'] = explode(",", $_COOKIE[$cookieName]);
    } else {
        $_SESSION['cart'] = [];
    }
}

// 3. UPDATE CART (FIXED)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Default to empty array if all checkboxes are unchecked
    $_SESSION['cart'] = $_POST['products'] ?? [];
    
    $cartString = implode(",", $_SESSION['cart']);
    setcookie($cookieName, $cartString, time() + 86400 * 30);
    
    header("Location: cookie_cart.php");
    exit();
}

// 4. LOGOUT
if (isset($_GET['logout'])) {
    $cartString = implode(",", $_SESSION['cart']);
    setcookie($cookieName, $cartString, time() + 86400 * 30);
    session_destroy();
    header("Location: cookie_cart.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<body>
<h2>Hello, <?= htmlspecialchars($username) ?>!</h2>
<form method="post">
  <?php
  $products = ["Apple", "Banana", "Orange", "Water"];
  foreach ($products as $p) {
      $checked = in_array($p, $_SESSION['cart']) ? "checked" : "";
      echo "<label><input type='checkbox' name='products[]' value='$p' $checked> $p</label><br>";
  }
  ?>
  <br><input type="submit" value="Save Cart">
</form>
<h3>Your current cart:</h3>
<ul>
<?= !empty($_SESSION['cart']) ? '<li>' . implode('</li><li>', $_SESSION['cart']) . '</li>' : '<li>No items</li>' ?>
</ul>
<a href="?logout=true">Logout</a>
</body>
</html>