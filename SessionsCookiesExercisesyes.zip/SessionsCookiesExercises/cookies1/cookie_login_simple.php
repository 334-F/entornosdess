<?php
// LOGIC BLOCK: Handle Login and Cookie Creation
$error = "";

// 1. Check if the user is already logged in (Cookie exists)
if (isset($_COOKIE['user_name'])) {
    $isLoggedIn = true;
    $username = $_COOKIE['user_name'];
} else {
    $isLoggedIn = false;

    // 2. If form is submitted, verify data
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $user = $_POST['username'] ?? '';
        $pass = $_POST['password'] ?? '';

        // Simple verification logic (Simulating a database check)
        // Requirement: "Upon submission, it verifies the data's accuracy"
        // For this exercise, let's assume the password must be "1234"
        if (!empty($user) && $pass === "1234") {
            
            // Data is correct: Create the cookie
            setcookie('user_name', $user, time() + (86400 * 30), "/"); // 30 days
            
            // Reload the page to recognize the cookie immediately
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();

        } else {
            // Requirement: "IF THE DATA IS INCORRECT, DISPLAY THE FORM AGAIN"
            $error = "Incorrect username or password. (Hint: Password is '1234')";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cookie Login</title>
    <style>
        body { font-family: sans-serif; padding: 20px; }
        .error { color: red; }
        .success { color: green; font-size: 1.2em; }
    </style>
</head>
<body>

    <?php if ($isLoggedIn): ?>
        
        <h1 class="success">Welcome back, <?php echo htmlspecialchars($username); ?>!</h1>
        <p>You were logged in automatically because a cookie exists.</p>
        
        <form method="post" action="logout_simple.php">
            <input type="submit" value="Log Out (Delete Cookie)">
        </form>

    <?php else: ?>

        <h1>Login</h1>
        
        <?php if ($error): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="post">
            <label>Username:</label><br>
            <input type="text" name="username" required><br><br>
            
            <label>Password:</label><br>
            <input type="password" name="password" required><br><br>
            
            <input type="submit" value="Login">
        </form>

    <?php endif; ?>

</body>
</html>