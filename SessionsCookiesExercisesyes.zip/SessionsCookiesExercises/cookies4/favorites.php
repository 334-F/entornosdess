<?php
session_start();

// Security: Redirect to login if no user is set
if (!isset($_SESSION['username'])) {
    header("Location: cookie_login.php");
    exit;
}

$username = $_SESSION['username'];
// Dynamic cookie name for this specific user
$cookieName = 'favorites_' . $username; 

// Ensure the session array exists
if (!isset($_SESSION['favorites'])) {
    $_SESSION['favorites'] = [];
}

// --- HANDLE MODIFICATIONS ---
// Requirement: "Favorite products can always be modified, deleted, added" [cite: 29]
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1. ADD PRODUCT
    if (isset($_POST['add']) && !empty($_POST['product'])) {
        $newProduct = htmlspecialchars(trim($_POST['product']));
        $_SESSION['favorites'][] = $newProduct;
    }

    // 2. DELETE PRODUCT
    if (isset($_POST['delete'])) {
        $index = (int)$_POST['delete'];
        if (isset($_SESSION['favorites'][$index])) {
            unset($_SESSION['favorites'][$index]);
            // Re-index array so it remains a clean list (0, 1, 2...) for JSON
            $_SESSION['favorites'] = array_values($_SESSION['favorites']);
        }
    }

    // 3. SAVE TO COOKIE IMMEDIATELY
    // Requirement: "saved directly in a cookie" 
    // Requirement: "Each time a user adds/modifies/deletes... record it in the cookie" 
    setcookie(
        $cookieName, 
        json_encode($_SESSION['favorites']), // Convert array to string
        time() + (86400 * 30), // Expires in 30 days
        "/"
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Favorites</title>
</head>
<body>

<h1>Welcome, <?php echo $username; ?>!</h1>

<h3>Your Favorite Products:</h3>
<ul>
    <?php if (empty($_SESSION['favorites'])): ?>
        <li>No favorites yet.</li>
    <?php else: ?>
        <?php foreach ($_SESSION['favorites'] as $index => $product): ?>
            <li>
                <?php echo $product; ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="delete" value="<?php echo $index; ?>">
                    <button type="submit" style="color:red; margin-left:10px;">Delete</button>
                </form>
            </li>
        <?php endforeach; ?>
    <?php endif; ?>
</ul>

<hr>

<h3>Add a new favorite:</h3>
<form method="POST">
    <input type="text" name="product" placeholder="Enter product name" required>
    <button type="submit" name="add">Add to Favorites</button>
</form>

<br><br>
<a href="logout.php">Log Out</a>

</body>
</html>