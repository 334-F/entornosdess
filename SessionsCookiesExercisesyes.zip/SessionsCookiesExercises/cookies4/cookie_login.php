<?php
session_start();

// If already logged in, go directly to the app
if (isset($_SESSION['username'])) {
    header("Location: favorites.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = htmlspecialchars(trim($_POST['username']));
    
    // 1. Save username to session
    $_SESSION['username'] = $username;

    // 2. Define the User-Specific Cookie Name
    // Requirement: "Remember that favorites are saved per user" 
    $cookieName = 'favorites_' . $username;

    // 3. Load favorites from Cookie if it exists
    // Requirement: "When the user logs back in, their favorite products are loaded" 
    if (isset($_COOKIE[$cookieName])) {
        // We use JSON to store the array as a string in the cookie
        $_SESSION['favorites'] = json_decode($_COOKIE[$cookieName], true);
    } else {
        // If no cookie exists, start with an empty list
        $_SESSION['favorites'] = [];
    }

    header("Location: favorites.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Favorites</title>
</head>
<body>
    <h2>Login to see your favorites</h2>
    <form method="POST">
        <label>Username:</label>
        <input type="text" name="username" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>