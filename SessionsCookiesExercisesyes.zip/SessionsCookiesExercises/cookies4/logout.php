<?php
session_start();
session_destroy(); // Destroy the session variables

// Note: We do not destroy the cookie, so data remains for next time.

header("Location: cookie_login.php");
exit;
?>