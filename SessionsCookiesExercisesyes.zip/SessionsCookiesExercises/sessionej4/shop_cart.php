<?php
session_start();

// 1. FIX: Handle Reset/Clear Cart at the very top
if (isset($_GET['reset'])) {
    session_destroy();
    // Make sure this filename matches your actual file name!
    header('Location: shop_cart.php'); 
    exit();
}

// 2. Handle adding/updating items
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // We use $_POST['quantity'] to capture input array
    foreach ($_POST['quantity'] as $item => $qty) {
        // Requirement: Allow modify or remove items 
        if ($qty > 0) {
            // Requirement: Select more than one unit 
            $_SESSION['cart'][$item] = $qty;
        } else {
            // If 0 is entered, remove the item
            unset($_SESSION['cart'][$item]);
        }
    }
}

$products = ['Apple', 'Banana', 'Orange', 'Water', 'Juice', 'Soda'];
?>
<!DOCTYPE html>
<html>
<body>
<h2>Shopping Cart</h2>
<form method="post">
<table border="1" cellpadding="5">
<tr><th>Product</th><th>Quantity</th></tr>
<?php foreach ($products as $p): ?>
<tr>
  <td><?= $p ?></td>
  <td>
    <input type="number" name="quantity[<?= $p ?>]" 
           value="<?= $_SESSION['cart'][$p] ?? 0 ?>" min="0">
  </td>
</tr>
<?php endforeach; ?>
</table>
<br>
<input type="submit" value="Update Cart">
</form>

<h3>Selected Products:</h3>
<ul>
<?php
// Requirement: Show all selected products at the end 
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item => $qty) {
        echo "<li>$item - $qty units</li>";
    }
} else {
    echo "<li>No products selected</li>";
}
?>
</ul>

<a href="?reset=true">Clear Cart</a>

</body>
</html>