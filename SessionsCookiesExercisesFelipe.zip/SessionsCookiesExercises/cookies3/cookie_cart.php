<?php
session_start();


if (!isset($_SESSION['username'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
        $_SESSION['username'] = trim($_POST['username']);
        header("Location: cookie_cart.php");
        exit();
    }
    echo '<form method="post">
        <h2>Login</h2><input name="username" required><input type="submit" value="Login">
    </form>';
    exit();
}


$username = $_SESSION['username'];
$cookieName = "cart_" . $username;

if (!isset($_SESSION['cart'])) {
    if (isset($_COOKIE[$cookieName]) && $_COOKIE[$cookieName] !== "") {
        $_SESSION['cart'] = explode(",", $_COOKIE[$cookieName]);
    } else {
        $_SESSION['cart'] = [];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $_SESSION['cart'] = [];
        setcookie($cookieName, "", time() - 3600); 

    } else {
        $_SESSION['cart'] = $_POST['products'] ?? [];
        $cartString = implode(",", $_SESSION['cart']);
        setcookie($cookieName, $cartString, time() + 86400 * 30);
    }
    header("Location: cookie_cart.php");
    exit();
}

if (isset($_GET['logout'])) {
    if (isset($_SESSION['cart'])) {
        $cartString = implode(",", $_SESSION['cart']);
        setcookie($cookieName, $cartString, time() + 86400 * 30);
    }
    
    session_destroy();
    header("Location: cookie_cart.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Carrito Persistente</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .actions { margin-top: 15px; }
        .actions form, .actions a { display: inline-block; margin-right: 10px; }
    </style>
</head>
<body>
    <h2>Hello, <?= htmlspecialchars($username) ?>!</h2>

    <form method="post">
        <h3>Selecciona tus productos:</h3>
        <?php
        $products = ["Apple", "Banana", "Orange", "Water"];
            foreach ($products as $p) {
            $checked = in_array($p, $_SESSION['cart']) ? "checked" : "";
            $safeP = htmlspecialchars($p); 
            echo "<label><input type='checkbox' name='products[]' value='$safeP' $checked> $safeP</label><br>";
        }
        ?>
        <br>
        <input type="submit" value="Save Cart">
    </form>

    <hr>

    <div class="actions">
        <form method="post">
            <input type="hidden" name="action" value="delete">
            <input type="submit" value="Delete Cart">
        </form>

        <a href="?logout=true">Logout</a>
    </div>

    <hr>

    <h3>Your current cart:</h3>
    <ul>
    <?= !empty($_SESSION['cart']) ? '<li>' . implode('</li><li>', $_SESSION['cart']) . '</li>' : '<li>No items</li>' ?>
    </ul>

</body>
</html>