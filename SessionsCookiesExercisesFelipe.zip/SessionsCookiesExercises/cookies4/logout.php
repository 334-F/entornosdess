<?php
session_start();
session_destroy();

header("Location: cookie_login.php");
exit;
?>