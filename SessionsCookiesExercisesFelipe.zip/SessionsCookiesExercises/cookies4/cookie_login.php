<?php
session_start();

if (isset($_SESSION['username'])) {
    header("Location: favorites.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = htmlspecialchars(trim($_POST['username']));
    
    $_SESSION['username'] = $username;

    $cookieName = 'favorites_' . $username;

    if (isset($_COOKIE[$cookieName])) {
        $_SESSION['favorites'] = json_decode($_COOKIE[$cookieName], true);
    } else {
        $_SESSION['favorites'] = [];
    }
    header("Location: favorites.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Favorites</title>
</head>
<body>
    <h2>Login to see your favorites</h2>
    <form method="POST">
        <label>Username:</label>
        <input type="text" name="username" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>