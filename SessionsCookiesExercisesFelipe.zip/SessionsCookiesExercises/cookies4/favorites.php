<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: cookie_login.php");
    exit;
}

$username = $_SESSION['username'];
$cookieName = 'favorites_' . $username; 

if (!isset($_SESSION['favorites'])) {
    $_SESSION['favorites'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1. ADD PRODUCT
    if (isset($_POST['add']) && !empty($_POST['product'])) {
        $newProduct = htmlspecialchars(trim($_POST['product']));
        $_SESSION['favorites'][] = $newProduct;
    }
    
    // 2. DELETE PRODUCT
    if (isset($_POST['delete'])) {
        $index = (int)$_POST['delete'];
        if (isset($_SESSION['favorites'][$index])) {
            unset($_SESSION['favorites'][$index]);
            $_SESSION['favorites'] = array_values($_SESSION['favorites']);
        }
    }

    setcookie(
        $cookieName, 
        json_encode($_SESSION['favorites']), // Guarda el array codificado como JSON
        time() + (86400 * 30), 
        "/" 
    );
    
    header("Location: favorites.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Favorites</title>
</head>
<body>

<h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>

<h3>Your Favorite Products:</h3>
<ul>
    <?php if (empty($_SESSION['favorites'])): ?>
        <li>No favorites yet.</li>
    <?php else: ?>
        <?php foreach ($_SESSION['favorites'] as $index => $product): ?>
            <li>
                <?php echo htmlspecialchars($product); ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="delete" value="<?php echo $index; ?>">
                    <button type="submit" style="color:red; margin-left:10px;">Delete</button>
                </form>
            </li>
        <?php endforeach; ?>
    <?php endif; ?>
</ul>

<hr>

<h3>Add a new favorite:</h3>
<form method="POST">
    <input type="text" name="product" placeholder="Enter product name" required>
    <button type="submit" name="add">Add to Favorites</button>
</form>

<br><br>
<a href="logout.php">Log Out</a>

</body>
</html>