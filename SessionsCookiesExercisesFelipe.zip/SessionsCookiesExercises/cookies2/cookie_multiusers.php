<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiple Cookies</title>
</head>
<body>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']); 

    $cookieName = "user_" . $username;

    echo "<h2>User: $username</h2>";
    echo "<p>Password received: $password</p>";

    if (isset($_COOKIE[$cookieName])) {
        echo "<p>Welcome back!</p>";
        echo "<p>Your last login was: " . $_COOKIE[$cookieName] . "</p>";
    } else {
        echo "<p>Hello $username, this is your first login!</p>";
    }

    $now = date("Y-m-d H:i:s");
    setcookie($cookieName, $now, time() + 86400 * 30);

    echo "<p>Current login time recorded: $now</p>";
    echo '<a href="cookie_multiusers.php">Login again</a>';

} else {
?>

<form method="post">
  <h2>Multiple Users Login</h2>
  Username: <input name="username" required><br><br>
  Password: <input name="password" type="password" required><br><br>
  <input type="submit" value="Login">
</form>

<?php } ?>

</body>
</html>
