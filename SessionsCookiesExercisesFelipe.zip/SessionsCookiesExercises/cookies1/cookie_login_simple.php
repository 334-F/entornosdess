<?php
$valid_password = "1234"; 
$error_message = "";
$is_logged_in = false;
$username = "";

if (isset($_COOKIE['user_name'])) {
    $is_logged_in = true;
    $username = htmlspecialchars($_COOKIE['user_name']); 

} else {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $submitted_user = trim($_POST['username'] ?? '');
        $submitted_pass = $_POST['password'] ?? '';

        if (!empty($submitted_user) && $submitted_pass === $valid_password) {
            
            setcookie('user_name', $submitted_user, time() + (86400 * 30), "/"); 

            header("Location: " . $_SERVER['PHP_SELF']);
            exit();

        } else {
            $error_message = "Incorrect username or password. (Password is: '1234')";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Cookie Login</title>
</head>
<body>

<?php
if ($is_logged_in) {
    echo "<h1>Welcome back, " . $username . "!</h1>";
    echo "<p>You were logged.</p>";
    
    echo '<p><a href="?logout=true">Log Out</a></p>';
    
    if (isset($_GET['logout'])) {
        setcookie('user_name', '', time() - 3600, "/"); 
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
    
} else {
    echo "<h1>Login to Access</h1>";
    
    if ($error_message) {
        echo "<p style='color: red;'>" . $error_message . "</p>";
    }
    
    echo '<form method="post" action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '">';
    echo '  <label for="username">Username:</label><br>';
    echo '  <input type="text" id="username" name="username" required><br><br>';
    echo '  <label for="password">Password (1234):</label><br>';
    echo '  <input type="password" id="password" name="password" required><br><br>';
    echo '  <input type="submit" value="Submit Login">';
    echo '</form>';
}
?>

</body>
</html>