<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['fruits'] = $_POST['fruits'] ?? [];
    header('Location: drinks.php');
    exit();
}

$saved_fruits = $_SESSION['fruits'] ?? [];
?>
<!DOCTYPE html>
<html>
<body>
<h2>Select your fruits</h2>
<form method="post">
  <input type="checkbox" name="fruits[]" value="Apple" 
    <?= in_array('Apple', $saved_fruits) ? 'checked' : '' ?>> Apple<br>
    
  <input type="checkbox" name="fruits[]" value="Banana" 
    <?= in_array('Banana', $saved_fruits) ? 'checked' : '' ?>> Banana<br>
    
  <input type="checkbox" name="fruits[]" value="Orange" 
    <?= in_array('Orange', $saved_fruits) ? 'checked' : '' ?>> Orange<br>
  <br>
  <input type="submit" value="Next">
</form>
</body>
</html>