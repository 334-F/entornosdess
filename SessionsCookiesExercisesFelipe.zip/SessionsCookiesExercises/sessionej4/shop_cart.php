<?php
session_start();

// Reset cart
if (isset($_GET['reset'])) {
    session_destroy();
    header('Location: shop_cart.php');
    exit();
}

// Products
$products = ['Apple', 'Banana', 'Orange', 'Water', 'Juice', 'Soda'];

// Update cart
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['quantity'] as $item => $qty) {
        $qty = (int)$qty;
        if ($qty > 0) {
            $_SESSION['cart'][$item] = $qty;
        } else {
            unset($_SESSION['cart'][$item]);
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart</title>
</head>
<body>
<h2>Shopping Cart</h2>

<form method="post">
    <table>
        <tr><th>Product</th><th>Quantity</th></tr>
        <?php foreach ($products as $p): ?>
        <tr>
            <td><?= $p ?></td>
            <td><input type="number" name="quantity[<?= $p ?>]" value="<?= $_SESSION['cart'][$p] ?? 0 ?>" min="0"></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <input type="submit" value="Update Cart">
</form>

<h3>Selected Items:</h3>
<ul>
<?php
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item => $qty) {
        echo "<li>$item - $qty units</li>";
    }
} else {
    echo "<li>Cart is empty.</li>";
}
?>
</ul>

<p><a href="?reset=true">Clear Cart</a></p>

</body>
</html>
